# 🎨 FormCraft Pro

<div align="center">

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![WordPress](https://img.shields.io/badge/WordPress-5.8%2B-blue.svg)
![PHP](https://img.shields.io/badge/PHP-7.4%2B-purple.svg)
![React](https://img.shields.io/badge/React-18.2-61dafb.svg)
![TypeScript](https://img.shields.io/badge/TypeScript-5.2-3178c6.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)

**یک Form Builder پیشرفته و مدرن برای وردپرس**

[ویژگی‌ها](#-ویژگی‌ها) • [نصب](#-نصب) • [استفاده](#-استفاده) • [توسعه](#-توسعه) • [مستندات](#-مستندات)

</div>

---

## 📋 فهرست مطالب

- [درباره پروژه](#-درباره-پروژه)
- [ویژگی‌ها](#-ویژگی‌ها)
- [پیش‌نیازها](#-پیش‌نیازها)
- [نصب](#-نصب)
- [استفاده](#-استفاده)
- [توسعه](#-توسعه)
- [ساختار پروژه](#-ساختار-پروژه)
- [REST API](#-rest-api)
- [مستندات](#-مستندات)
- [مشارکت](#-مشارکت)
- [لایسنس](#-لایسنس)

---

## 🎯 درباره پروژه

FormCraft Pro یک پلاگین وردپرس قدرتمند برای ساخت فرم است که با تکنولوژی‌های مدرن ساخته شده:

- **Frontend:** React 18 + TypeScript + Tailwind CSS
- **Backend:** PHP + WordPress REST API
- **Build Tool:** Vite
- **State Management:** Zustand
- **Drag & Drop:** @dnd-kit

---

## ✨ ویژگی‌ها

### 🎨 رابط کاربری مدرن
- ✅ طراحی زیبا و کاربرپسند با React
- ✅ Drag & Drop برای مرتب‌سازی فیلدها
- ✅ پیش‌نمایش زنده فرم
- ✅ پشتیبانی کامل از RTL

### 📝 انواع فیلد
- ✅ فیلد متنی (Text)
- ✅ ایمیل (Email)
- ✅ متن چند خطی (Textarea)
- ✅ لیست کشویی (Select)
- ✅ دکمه رادیویی (Radio)
- ✅ چک‌باکس (Checkbox)
- ✅ عدد (Number)
- ✅ تاریخ (Date)
- ✅ آپلود فایل (File)

### 🎨 سفارشی‌سازی
- ✅ تغییر رنگ برچسب
- ✅ تغییر رنگ حاشیه
- ✅ تنظیم عرض فیلد
- ✅ اعتبارسنجی سفارشی

### 📊 مدیریت ورودی‌ها
- ✅ مشاهده تمام ورودی‌ها
- ✅ فیلتر و جستجو
- ✅ Export به CSV
- ✅ حذف ورودی‌ها

### 🔧 قابلیت‌های پیشرفته
- ✅ Import/Export فرم‌ها
- ✅ تنظیمات ایمیل
- ✅ Google reCAPTCHA
- ✅ System Status
- ✅ راهنمای کامل

---

## 📋 پیش‌نیازها

### سرور:
- WordPress 5.8 یا بالاتر
- PHP 7.4 یا بالاتر
- MySQL 5.6 یا بالاتر

### توسعه:
- Node.js 16+ و npm
- Git

---

## 🚀 نصب

### نصب از فایل ZIP

1. فایل `formcraft-pro.zip` را دانلود کنید
2. به داشبورد وردپرس بروید
3. به **Plugins > Add New > Upload Plugin** بروید
4. فایل ZIP را آپلود و نصب کنید
5. پلاگین را فعال کنید

### نصب دستی

```bash
# کلون کردن ریپو
git clone https://github.com/your-username/formcraft-pro.git

# رفتن به پوشه پروژه
cd formcraft-pro

# نصب وابستگی‌ها
npm install

# ساخت فایل‌های production
npm run build

# کپی به وردپرس
cp -r . /path/to/wordpress/wp-content/plugins/formcraft-pro
```

---

## 💡 استفاده

### 1. ساخت فرم جدید

1. به **FormCraft > فرم جدید** بروید
2. عنوان فرم را وارد کنید
3. فیلدهای مورد نظر را اضافه کنید
4. با Drag & Drop ترتیب را تنظیم کنید
5. روی **ذخیره فرم** کلیک کنید

### 2. نمایش فرم در سایت

از Shortcode استفاده کنید:

```php
[formcraft id="1"]
```

یا در قالب:

```php
<?php echo do_shortcode('[formcraft id="1"]'); ?>
```

### 3. مشاهده ورودی‌ها

1. به **FormCraft > ورودی‌ها** بروید
2. فرم مورد نظر را انتخاب کنید
3. ورودی‌ها را مشاهده یا Export کنید

---

## 🛠 توسعه

### راه‌اندازی محیط توسعه

```bash
# نصب وابستگی‌ها
npm install

# اجرای dev server با HMR
npm run dev

# ساخت برای production
npm run build
```

### ساختار دستورات

```json
{
  "dev": "vite",           // Development server
  "build": "vite build"    // Production build
}
```

---

## 📁 ساختار پروژه

```
formcraft-pro/
├── assets/                 # فایل‌های استاتیک
│   ├── icon.svg
│   ├── frontend.css
│   └── frontend.js
├── build/                  # خروجی build
│   ├── admin.bundle.js
│   └── admin.styles.css
├── includes/               # کلاس‌های PHP
│   ├── class-formcraft-activator.php
│   └── class-formcraft-frontend.php
├── src/
│   ├── admin/              # کد React
│   │   ├── components/
│   │   ├── pages/
│   │   ├── store/
│   │   └── App.tsx
│   └── php/                # کد PHP
│       ├── Controllers/
│       └── Services/
├── formcraft-pro.php       # فایل اصلی
├── package.json
├── tsconfig.json
└── vite.config.ts
```

---

## 🔌 REST API

### Endpoints

#### فرم‌ها

```http
GET    /wp-json/fcp/v1/forms
GET    /wp-json/fcp/v1/forms/{id}
POST   /wp-json/fcp/v1/forms
PUT    /wp-json/fcp/v1/forms/{id}
DELETE /wp-json/fcp/v1/forms/{id}
```

#### ورودی‌ها

```http
POST   /wp-json/fcp/v1/entries
GET    /wp-json/fcp/v1/entries/{id}
GET    /wp-json/fcp/v1/forms/{id}/entries
DELETE /wp-json/fcp/v1/entries/{id}
```

---

## 📚 مستندات

### راهنماهای موجود

- [راهنمای نصب فارسی](INSTALL-FA.md)
- [گزارش نهایی](گزارش-نهایی-کامل.md)

---

## 🤝 مشارکت

مشارکت شما استقبال می‌شود! لطفاً این مراحل را دنبال کنید:

1. Fork کنید
2. یک branch جدید بسازید
3. تغییرات را commit کنید
4. Push کنید
5. یک Pull Request باز کنید

---

## 📄 لایسنس

این پروژه تحت لایسنس MIT منتشر شده است.

---

<div align="center">

**ساخته شده با ❤️ برای جامعه وردپرس**

</div>
